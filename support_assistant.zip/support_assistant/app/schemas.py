"""
Pydantic Schemas and TypedDict State for Zepto Support Assistant (Module 3).
"""

from typing import List, Optional
from typing_extensions import TypedDict
from pydantic import BaseModel, Field
from enum import Enum


class IntentEnum(str, Enum):
    GENERAL_QUESTION = "general_question"
    POLICY_QUESTION = "policy_question"


class AskRequest(BaseModel):
    query: str = Field(..., description="Customer query to the Zepto support assistant", min_length=1)
    
    # Allow 'question' as alternative key for compatibility
    def __init__(self, **data):
        if "question" in data and "query" not in data:
            data["query"] = data["question"]
        super().__init__(**data)


class AskResponse(BaseModel):
    answer: str = Field(..., description="The generated response or canned refusal")
    sources: List[str] = Field(default_factory=list, description="List of policy sources/filenames used to formulate the answer")
    confidence: float = Field(..., description="Confidence score between 0.0 and 1.0", ge=0.0, le=1.0)


class IntentClassificationResponse(BaseModel):
    intent: IntentEnum = Field(..., description="Classified query intent: either policy_question or general_question")
    reasoning: Optional[str] = Field(None, description="Brief explanation for intent classification")


class RetrievedChunk(BaseModel):
    policy_id: str
    policy_title: str
    source: str
    content: str
    score: float


class AgentState(TypedDict):
    query: str
    intent: str
    retrieved_chunks: List[dict]
    answer: str
    sources: List[str]
    confidence: float
