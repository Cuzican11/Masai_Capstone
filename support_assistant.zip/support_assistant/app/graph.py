"""
LangGraph Workflow Module for Zepto Support Assistant (Module 3).
Defines a StateGraph implementing:
1. Intent Classification (Keyword Heuristic in MOCK_LLM=1, or Gemini API in MOCK_LLM=0)
2. Conditional Routing:
   - general_question -> Canned Refusal node
   - policy_question  -> Retrieval & Response Generation node (Templated in MOCK_LLM=1, Gemini in MOCK_LLM=0)
"""

import os
import re
from typing import Dict, Any, List
from langgraph.graph import StateGraph, END
from schemas import AgentState, AskResponse, IntentEnum
from retrieval import retrieve_top_k
from config import MOCK_LLM, GEMINI_API_KEY

CANNED_REFUSAL = (
    "I am Zepto's policy assistant. I can only assist with Zepto delivery, order, "
    "return, refund, cancellation, pass membership, pricing, and service policy questions."
)

# Zepto domain keywords for heuristic routing when MOCK_LLM=1
POLICY_KEYWORDS = [
    "return", "refund", "cancel", "delivery", "deliver", "10 minute", "sla", "delay",
    "pass", "membership", "subscribe", "subscription", "pricing", "price", "mrp", "surge",
    "fee", "charge", "payment", "upi", "cod", "cash", "wallet", "rider", "driver",
    "safety", "conduct", "harassment", "tip", "fresh", "freshness", "quality", "expire",
    "expiry", "stale", "damaged", "perishable", "milk", "vegetable", "fruit", "privacy",
    "masking", "virtual number", "data", "location", "order", "items", "replace",
    "dark store", "substitute", "eta", "late", "compensation"
]


def classify_intent_heuristic(query: str) -> str:
    """
    Keyword-based heuristic intent classifier for MOCK_LLM=1 baseline.
    """
    q_lower = query.lower()
    
    # Check if query matches policy domain keywords
    for kw in POLICY_KEYWORDS:
        if kw in q_lower:
            return IntentEnum.POLICY_QUESTION.value
            
    # Default chitchat / off-topic queries (e.g. 'hello', 'who won the match', 'write python code')
    return IntentEnum.GENERAL_QUESTION.value


def classify_intent_gemini(query: str) -> str:
    """
    Gemini-powered intent classification for MOCK_LLM=0.
    """
    try:
        from google import genai
        from google.genai import types
        
        client = genai.Client(api_key=GEMINI_API_KEY)
        
        prompt = f"""You are a query router for Zepto customer support.
Classify the following user query as either:
- 'policy_question': questions about Zepto services, orders, deliveries, returns, refunds, cancellations, memberships, pricing, safety, freshness, or customer policies.
- 'general_question': general chitchat, greetings, programming questions, weather, sports, or off-topic inquiries unrelated to Zepto policies.

User Query: "{query}"

Output ONLY either 'policy_question' or 'general_question'."""

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )
        
        text = response.text.strip().lower()
        if "policy_question" in text:
            return IntentEnum.POLICY_QUESTION.value
        return IntentEnum.GENERAL_QUESTION.value
    except Exception as e:
        print(f"Gemini intent classification fallback to heuristic due to: {e}")
        return classify_intent_heuristic(query)


# -----------------------------------------------------------------
# LangGraph Nodes
# -----------------------------------------------------------------

def classify_intent_node(state: AgentState) -> Dict[str, Any]:
    """
    Node 1: Classifies the user's intent into either 'policy_question' or 'general_question'.
    """
    query = state.get("query", "")
    
    if MOCK_LLM or not GEMINI_API_KEY:
        intent = classify_intent_heuristic(query)
    else:
        intent = classify_intent_gemini(query)
        
    return {"intent": intent}


def handle_general_question_node(state: AgentState) -> Dict[str, Any]:
    """
    Node 2: Returns canned refusal for general / off-topic queries.
    """
    return {
        "answer": CANNED_REFUSAL,
        "sources": [],
        "confidence": 1.0
    }


def handle_policy_question_node(state: AgentState) -> Dict[str, Any]:
    """
    Node 3: Retrieves top 3 relevant chunks from ChromaDB and constructs response.
    - If MOCK_LLM=1: Uses deterministic templated response incorporating retrieved snippets.
    - If MOCK_LLM=0: Prompts Gemini model with structured output.
    """
    query = state.get("query", "")
    retrieved_chunks = retrieve_top_k(query, k=3)
    
    sources = list(dict.fromkeys([chunk["source"] for chunk in retrieved_chunks]))
    
    if MOCK_LLM or not GEMINI_API_KEY:
        # Construct deterministic templated response for MOCK_LLM=1
        if not retrieved_chunks:
            answer = "According to Zepto policy records, no matching policy was found for your query. Please contact customer support."
            confidence = 0.50
        else:
            top_chunk = retrieved_chunks[0]
            snippets_text = "\n\n".join([f"[{c['source']}] {c['text']}" for c in retrieved_chunks])
            answer = (
                f"Based on Zepto's official policy documentation ({top_chunk['source']}):\n\n"
                f"{top_chunk['text']}\n\n"
                f"For additional details, refer to: {', '.join(sources)}."
            )
            confidence = float(top_chunk.get("score", 0.90))
    else:
        # Real LLM Generation via Gemini with Structured Output
        try:
            from google import genai
            from google.genai import types
            
            client = genai.Client(api_key=GEMINI_API_KEY)
            context = "\n\n".join([
                f"--- Document: {c['source']} ({c['policy_title']}) ---\n{c['text']}"
                for c in retrieved_chunks
            ])
            
            system_instruction = (
                "You are Zepto's AI Policy Assistant. Answer the customer question accurately "
                "and concisely using ONLY the provided policy context. Cite the specific policy source "
                "and assign an appropriate confidence score (0.0 to 1.0)."
            )
            
            prompt = f"""Context:
{context}

Customer Question: {query}
"""
            response = client.models.generate_content(
                model="gemini-2.5-flash",
                contents=prompt,
                config=types.GenerateContentConfig(
                    system_instruction=system_instruction,
                    response_mime_type="application/json",
                    response_schema=AskResponse,
                    temperature=0.2
                )
            )
            
            import json
            parsed = json.loads(response.text)
            answer = parsed.get("answer", "")
            # Merge sources
            llm_sources = parsed.get("sources", [])
            all_sources = list(dict.fromkeys(llm_sources + sources))
            confidence = float(parsed.get("confidence", 0.95))
            
            return {
                "retrieved_chunks": retrieved_chunks,
                "answer": answer,
                "sources": all_sources,
                "confidence": confidence
            }
        except Exception as e:
            print(f"Gemini generation fallback to template due to: {e}")
            top_chunk = retrieved_chunks[0] if retrieved_chunks else {"source": "policies", "text": "Policy lookup", "score": 0.85}
            answer = f"Based on Zepto policy ({top_chunk['source']}):\n{top_chunk['text']}"
            confidence = 0.85
            
    return {
        "retrieved_chunks": retrieved_chunks,
        "answer": answer,
        "sources": sources,
        "confidence": confidence
    }


def route_intent(state: AgentState) -> str:
    """
    Conditional edge function routing based on classified intent.
    """
    intent = state.get("intent", IntentEnum.GENERAL_QUESTION.value)
    if intent == IntentEnum.POLICY_QUESTION.value:
        return "handle_policy"
    return "handle_general"


# -----------------------------------------------------------------
# StateGraph Construction
# -----------------------------------------------------------------

def create_support_graph():
    """
    Builds and compiles the LangGraph StateGraph.
    """
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("classify_intent", classify_intent_node)
    workflow.add_node("handle_general", handle_general_question_node)
    workflow.add_node("handle_policy", handle_policy_question_node)
    
    # Set entry point
    workflow.set_entry_point("classify_intent")
    
    # Add conditional edge from classify_intent
    workflow.add_conditional_edges(
        "classify_intent",
        route_intent,
        {
            "handle_general": "handle_general",
            "handle_policy": "handle_policy"
        }
    )
    
    # Connect terminal nodes to END
    workflow.add_edge("handle_general", END)
    workflow.add_edge("handle_policy", END)
    
    # Compile graph
    app = workflow.compile()
    return app


# Singleton compiled graph
support_agent_graph = create_support_graph()


def ask_assistant(query: str) -> AskResponse:
    """
    High-level entry point to run a query through the LangGraph workflow.
    """
    initial_state = {
        "query": query,
        "intent": "",
        "retrieved_chunks": [],
        "answer": "",
        "sources": [],
        "confidence": 0.0
    }
    
    final_state = support_agent_graph.invoke(initial_state)
    
    return AskResponse(
        answer=final_state["answer"],
        sources=final_state["sources"],
        confidence=final_state["confidence"]
    )


if __name__ == "__main__":
    print("Testing LangGraph Support Assistant (MOCK_LLM=1)...")
    
    # Test Policy Question
    q1 = "What is the return window for perishable items like milk and vegetables?"
    res1 = ask_assistant(q1)
    print(f"\nQuery: '{q1}'")
    print(f"Answer: {res1.answer[:150]}...")
    print(f"Sources: {res1.sources}")
    print(f"Confidence: {res1.confidence}")
    
    # Test General Question
    q2 = "Who won the football world cup?"
    res2 = ask_assistant(q2)
    print(f"\nQuery: '{q2}'")
    print(f"Answer: {res2.answer}")
    print(f"Sources: {res2.sources}")
    print(f"Confidence: {res2.confidence}")
