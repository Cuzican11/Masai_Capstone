-- ====================================================================
-- Zepto Capstone: Module 1 SQL Analytical Queries
-- Demonstrating: WHERE, ORDER BY, LIMIT, DISTINCT, IN, BETWEEN, JOIN
-- ====================================================================

-- Query 1: Demonstrates [WHERE, ORDER BY, LIMIT, JOIN]
-- Objective: Retrieve Top 5 most premium in-stock books with category information.
SELECT 
    b.book_id,
    b.title,
    c.category_name,
    b.price_inr,
    b.star_rating,
    b.availability
FROM books b
JOIN categories c ON b.category_id = c.category_id
WHERE b.availability = 1
ORDER BY b.price_inr DESC
LIMIT 5;


-- Query 2: Demonstrates [DISTINCT, ORDER BY]
-- Objective: Retrieve distinct star ratings with aggregated metrics across catalog.
SELECT DISTINCT 
    star_rating,
    COUNT(*) AS total_titles,
    ROUND(AVG(price_inr), 2) AS avg_price_inr,
    MIN(price_inr) AS min_price_inr,
    MAX(price_inr) AS max_price_inr
FROM books
GROUP BY star_rating
ORDER BY star_rating DESC;


-- Query 3: Demonstrates [IN, JOIN, WHERE, ORDER BY]
-- Objective: Filter books belonging to specific curated categories ('Mystery', 'Travel') with rating >= 3.
SELECT 
    b.book_id,
    b.title,
    c.category_name,
    b.price_inr,
    b.star_rating
FROM books b
JOIN categories c ON b.category_id = c.category_id
WHERE c.category_name IN ('Mystery', 'Travel')
  AND b.star_rating >= 3
ORDER BY c.category_name ASC, b.price_inr DESC;


-- Query 4: Demonstrates [BETWEEN, WHERE, ORDER BY]
-- Objective: Identify mid-to-high tier books priced between 2000 INR and 4500 INR with at least 4-star rating.
SELECT 
    book_id,
    title,
    price_gbp,
    price_inr,
    star_rating,
    availability
FROM books
WHERE price_inr BETWEEN 2000.00 AND 4500.00
  AND star_rating >= 4
ORDER BY price_inr ASC;


-- Query 5: Demonstrates [JOIN, GROUP BY, ORDER BY]
-- Objective: Comprehensive category-level pricing and inventory summary.
SELECT 
    c.category_id,
    c.category_name,
    COUNT(b.book_id) AS total_books,
    ROUND(AVG(b.price_gbp), 2) AS avg_price_gbp,
    ROUND(AVG(b.price_inr), 2) AS avg_price_inr,
    MIN(b.price_inr) AS min_price_inr,
    MAX(b.price_inr) AS max_price_inr
FROM categories c
JOIN books b ON c.category_id = b.category_id
GROUP BY c.category_id, c.category_name
ORDER BY total_books DESC, avg_price_inr DESC;
