"""
Scraper Module for Zepto Data Pipeline.
Extracts book pricing and catalog data from books.toscrape.com.
Collects at least 60 books across at least 3 categories using requests and BeautifulSoup.
"""

import re
import time
import requests
from bs4 import BeautifulSoup
from typing import List, Dict, Any
from urllib.parse import urljoin

BASE_URL = "https://books.toscrape.com/"

# Categories to target (guaranteeing >= 3 categories and >= 60 books)
TARGET_CATEGORIES = [
    "Mystery",
    "Sequential Art",
    "Historical Fiction",
    "Travel"
]


def get_category_links() -> Dict[str, str]:
    """
    Fetches the home page and extracts category names and their corresponding URLs.
    """
    response = requests.get(BASE_URL, timeout=15)
    response.raise_for_status()
    soup = BeautifulSoup(response.content, "html.parser")
    
    category_links = {}
    nav_list = soup.select(".nav-list > li > ul > li > a")
    for link in nav_list:
        cat_name = link.get_text(strip=True)
        href = link.get("href")
        if cat_name in TARGET_CATEGORIES:
            full_url = urljoin(BASE_URL, href)
            category_links[cat_name] = full_url
            
    return category_links


def scrape_category_books(category_name: str, category_url: str, min_books_per_category: int = 20) -> List[Dict[str, Any]]:
    """
    Scrapes books from a specific category, following pagination if available.
    """
    books = []
    current_url = category_url
    
    while current_url and len(books) < min_books_per_category:
        response = requests.get(current_url, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, "html.parser")
        
        product_pods = soup.select("article.product_pod")
        for pod in product_pods:
            # 1. Title
            title_tag = pod.select_one("h3 > a")
            title = title_tag.get("title") or title_tag.get_text(strip=True) if title_tag else "Unknown Title"
            
            # 2. Price
            price_tag = pod.select_one("p.price_color")
            price_raw = price_tag.get_text(strip=True) if price_tag else "0.0"
            # Remove any currency symbols (GBP £ or unicode encoding artifacts like Â£)
            price_match = re.search(r"[\d\.]+", price_raw)
            price_gbp = float(price_match.group(0)) if price_match else 0.0
            
            # 3. Star rating
            rating_tag = pod.select_one("p.star-rating")
            star_rating = "Zero"
            if rating_tag:
                classes = rating_tag.get("class", [])
                for cls in classes:
                    if cls != "star-rating":
                        star_rating = cls
                        break
                        
            # 4. Availability
            avail_tag = pod.select_one("p.instock.availability")
            availability = avail_tag.get_text(strip=True) if avail_tag else "Unavailable"
            
            books.append({
                "title": title,
                "price": price_gbp,
                "star_rating": star_rating,
                "availability": availability,
                "category": category_name
            })
            
            if len(books) >= min_books_per_category:
                break
                
        # Check for next page
        next_li = soup.select_one("li.next > a")
        if next_li and len(books) < min_books_per_category:
            next_href = next_li.get("href")
            current_url = urljoin(current_url, next_href)
            time.sleep(0.3)  # Polite crawling delay
        else:
            current_url = None
            
    return books


def scrape_all_books(min_total_books: int = 60) -> List[Dict[str, Any]]:
    """
    Main extraction function: collects >= 60 books across at least 3 categories.
    """
    print("=" * 60)
    print("Step 1: Extracting book data from books.toscrape.com...")
    print("=" * 60)
    
    category_links = get_category_links()
    print(f"Found {len(category_links)} target categories: {list(category_links.keys())}")
    
    all_books = []
    for cat_name, cat_url in category_links.items():
        print(f"Scraping category: '{cat_name}'...")
        cat_books = scrape_category_books(cat_name, cat_url, min_books_per_category=20)
        print(f"  -> Extracted {len(cat_books)} books from '{cat_name}'.")
        all_books.extend(cat_books)
        time.sleep(0.5)
        
    print(f"\nTotal books extracted: {len(all_books)} across {len(category_links)} categories.")
    assert len(all_books) >= min_total_books, f"Expected at least {min_total_books} books, got {len(all_books)}"
    assert len(category_links) >= 3, f"Expected at least 3 categories, got {len(category_links)}"
    return all_books


if __name__ == "__main__":
    books = scrape_all_books()
    print("\nSample Extracted Record:")
    print(books[0] if books else "No records")
