"""
Exploratory Data Analysis (EDA) Module for Zepto Analytics.
Performs:
1. Missing values analysis and policy application (<5% drop, 5-30% impute, >30% drop/flag)
2. Univariate analysis with IQR outlier detection
3. Bivariate analysis with correlation heatmap
4. Multivariate analysis: 4-chart survival data story
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Tuple, Dict, Any

FIGURES_DIR = os.path.join(os.path.dirname(__file__), "..", "reports", "figures")
os.makedirs(FIGURES_DIR, exist_ok=True)


def analyze_missing_values(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Analyzes missing value percentages and applies systematic cleaning rules:
    - < 5%: Drop missing rows
    - 5% - 30%: Impute (e.g. median for numeric)
    - > 30%: Drop column or create explicit missing flag
    """
    print("\n" + "=" * 60)
    print("4.1 MISSING VALUES ANALYSIS & POLICY APPLICATION")
    print("=" * 60)
    
    total_rows = len(df)
    missing_series = df.isnull().sum()
    pct_series = (missing_series / total_rows) * 100
    
    actions = []
    for col in df.columns:
        pct = pct_series[col]
        if pct == 0:
            action = "None (No missing values)"
        elif pct < 5.0:
            action = "Drop rows (< 5% threshold)"
        elif 5.0 <= pct <= 30.0:
            action = "Impute with median/mode (5% - 30% threshold)"
        else:
            action = "Drop column / Flag (> 30% threshold)"
        actions.append(action)
        
    missing_report = pd.DataFrame({
        "Column": df.columns,
        "Missing_Count": missing_series.values,
        "Missing_Pct": pct_series.values.round(2),
        "Action_Policy": actions
    })
    
    print("\nMissing Values Audit:")
    print(missing_report[missing_report["Missing_Count"] > 0].to_string(index=False))
    
    # Apply cleaning based on policies for EDA exploration dataset
    df_cleaned = df.copy()
    
    # 1. Drop columns with > 30% missing (e.g. 'deck')
    cols_to_drop = [col for col in df.columns if pct_series[col] > 30.0]
    if cols_to_drop:
        print(f"\nDropping columns with > 30% missing: {cols_to_drop}")
        df_cleaned = df_cleaned.drop(columns=cols_to_drop)
        
    # 2. Drop rows with < 5% missing (e.g. 'embarked', 'embark_town')
    cols_drop_rows = [col for col in df_cleaned.columns if 0 < pct_series.get(col, 0) < 5.0]
    if cols_drop_rows:
        initial_len = len(df_cleaned)
        df_cleaned = df_cleaned.dropna(subset=cols_drop_rows)
        print(f"Dropped {initial_len - len(df_cleaned)} rows with < 5% missing in {cols_drop_rows}.")
        
    # 3. Impute columns with 5% - 30% missing (e.g. 'age')
    cols_impute = [col for col in df_cleaned.columns if 5.0 <= pct_series.get(col, 0) <= 30.0]
    for col in cols_impute:
        if pd.api.types.is_numeric_dtype(df_cleaned[col]):
            median_val = df_cleaned[col].median()
            df_cleaned[col] = df_cleaned[col].fillna(median_val)
            print(f"Imputed '{col}' missing values with median: {median_val:.2f}")
        else:
            mode_val = df_cleaned[col].mode()[0]
            df_cleaned[col] = df_cleaned[col].fillna(mode_val)
            print(f"Imputed '{col}' missing values with mode: '{mode_val}'")
            
    print(f"\nCleaned dataset shape after missing value policies: {df_cleaned.shape}")
    return missing_report, df_cleaned


def detect_outliers_iqr(df: pd.DataFrame, numeric_cols: list = ["age", "fare"]) -> Dict[str, Dict[str, Any]]:
    """
    4.2 Univariate Analysis: Detects outliers using the Interquartile Range (IQR) method:
    IQR = Q3 - Q1
    Lower Bound = Q1 - 1.5 * IQR
    Upper Bound = Q3 + 1.5 * IQR
    """
    print("\n" + "=" * 60)
    print("4.2 UNIVARIATE ANALYSIS & IQR OUTLIER DETECTION")
    print("=" * 60)
    
    outlier_summary = {}
    
    for col in numeric_cols:
        if col not in df.columns:
            continue
        series = df[col].dropna()
        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        iqr = q3 - q1
        lower_bound = q1 - 1.5 * iqr
        upper_bound = q3 + 1.5 * iqr
        
        outliers = series[(series < lower_bound) | (series > upper_bound)]
        outlier_pct = (len(outliers) / len(series)) * 100
        
        outlier_summary[col] = {
            "Q1": round(q1, 2),
            "Q3": round(q3, 2),
            "IQR": round(iqr, 2),
            "Lower_Bound": round(lower_bound, 2),
            "Upper_Bound": round(upper_bound, 2),
            "Outlier_Count": len(outliers),
            "Outlier_Pct": round(outlier_pct, 2)
        }
        
        print(f"\nFeature: '{col}'")
        print(f"  Q1: {q1:.2f}, Q3: {q3:.2f}, IQR: {iqr:.2f}")
        print(f"  Lower Bound: {lower_bound:.2f}, Upper Bound: {upper_bound:.2f}")
        print(f"  Outliers Detected: {len(outliers)} ({outlier_pct:.2f}% of total values)")
        if len(outliers) > 0:
            print(f"  Outlier Range: Min={outliers.min():.2f}, Max={outliers.max():.2f}")
            
    return outlier_summary


def plot_correlation_heatmap(df: pd.DataFrame, output_path: str = None) -> str:
    """
    4.3 Bivariate Analysis: Creates and saves a correlation heatmap for numerical variables.
    """
    print("\n" + "=" * 60)
    print("4.3 BIVARIATE ANALYSIS & CORRELATION HEATMAP")
    print("=" * 60)
    
    if output_path is None:
        output_path = os.path.join(FIGURES_DIR, "correlation_heatmap.png")
        
    numeric_df = df.select_dtypes(include=[np.number])
    corr = numeric_df.corr()
    
    plt.figure(figsize=(10, 8), dpi=300)
    mask = np.triu(np.ones_like(corr, dtype=bool))
    cmap = sns.diverging_palette(230, 20, as_cmap=True)
    
    sns.heatmap(
        corr,
        mask=mask,
        cmap=cmap,
        vmax=1.0,
        vmin=-1.0,
        center=0,
        square=True,
        linewidths=0.5,
        annot=True,
        fmt=".2f",
        cbar_kws={"shrink": 0.8}
    )
    plt.title("Titanic Feature Correlation Heatmap", fontsize=14, fontweight="bold", pad=15)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    
    print(f"Correlation heatmap saved to: {output_path}")
    return output_path


def plot_multivariate_data_story(df: pd.DataFrame, output_path: str = None) -> str:
    """
    4.4 Multivariate Analysis: 4-chart data story explaining survival factors.
    1. Survival Rate by Class and Sex
    2. Age Distribution by Survival Status across Passenger Classes
    3. Fare vs Age by Survival Status & Embarkation Port
    4. Family Size (sibsp + parch + 1) vs Survival Rate
    """
    print("\n" + "=" * 60)
    print("4.4 MULTIVARIATE ANALYSIS: 4-CHART SURVIVAL DATA STORY")
    print("=" * 60)
    
    if output_path is None:
        output_path = os.path.join(FIGURES_DIR, "multivariate_data_story.png")
        
    plot_df = df.copy()
    plot_df["family_size"] = plot_df["sibsp"] + plot_df["parch"] + 1
    plot_df["survival_status"] = plot_df["survived"].map({1: "Survived", 0: "Perished"})
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 12), dpi=300)
    sns.set_theme(style="whitegrid")
    
    # -------------------------------------------------------------
    # Chart 1: Survival Rate by Passenger Class and Sex
    # -------------------------------------------------------------
    sns.barplot(
        data=plot_df,
        x="pclass",
        y="survived",
        hue="sex",
        palette={"male": "#3498db", "female": "#e74c3c"},
        ax=axes[0, 0],
        ci=None,
        edgecolor="black"
    )
    axes[0, 0].set_title("1. Survival Rate by Passenger Class & Sex\n('Women & Children First' + Socioeconomic Privilege)", fontsize=12, fontweight="bold")
    axes[0, 0].set_xlabel("Passenger Class (1 = 1st, 2 = 2nd, 3 = 3rd)", fontsize=10)
    axes[0, 0].set_ylabel("Survival Rate (0.0 to 1.0)", fontsize=10)
    axes[0, 0].set_ylim(0, 1.05)
    for p in axes[0, 0].patches:
        height = p.get_height()
        if height > 0:
            axes[0, 0].annotate(f"{height:.1%}", (p.get_x() + p.get_width() / 2., height / 2),
                                ha='center', va='center', color='white', fontweight='bold', fontsize=10)
                                
    # -------------------------------------------------------------
    # Chart 2: Age Distribution by Survival across Classes
    # -------------------------------------------------------------
    sns.violinplot(
        data=plot_df,
        x="pclass",
        y="age",
        hue="survival_status",
        split=True,
        palette={"Survived": "#2ecc71", "Perished": "#95a5a6"},
        ax=axes[0, 1],
        inner="quartile"
    )
    axes[0, 1].set_title("2. Age Distribution vs Survival across Passenger Classes\n(Higher Child Survival in 1st & 2nd Class)", fontsize=12, fontweight="bold")
    axes[0, 1].set_xlabel("Passenger Class", fontsize=10)
    axes[0, 1].set_ylabel("Age (Years)", fontsize=10)
    
    # -------------------------------------------------------------
    # Chart 3: Fare vs Age by Survival & Embarkation
    # -------------------------------------------------------------
    scatter = sns.scatterplot(
        data=plot_df,
        x="age",
        y="fare",
        hue="survival_status",
        style="embark_town",
        palette={"Survived": "#2ecc71", "Perished": "#e74c3c"},
        alpha=0.75,
        s=70,
        ax=axes[1, 0]
    )
    axes[1, 0].set_title("3. Fare vs Age by Survival & Embarkation Town\n(High Fare / 1st Class Embarkation Strongly Linked to Survival)", fontsize=12, fontweight="bold")
    axes[1, 0].set_xlabel("Age (Years)", fontsize=10)
    axes[1, 0].set_ylabel("Fare ($/GBP)", fontsize=10)
    axes[1, 0].set_yscale("log")
    axes[1, 0].set_ylabel("Fare (Log Scale)", fontsize=10)
    
    # -------------------------------------------------------------
    # Chart 4: Family Size vs Survival Rate
    # -------------------------------------------------------------
    family_stats = plot_df.groupby("family_size")["survived"].agg(["mean", "count"]).reset_index()
    sns.barplot(
        data=family_stats,
        x="family_size",
        y="mean",
        palette="viridis",
        ax=axes[1, 1],
        edgecolor="black"
    )
    axes[1, 1].set_title("4. Survival Rate by Family Size\n(Moderate Families [2-4] Had Highest Survival vs Solitary/Large)", fontsize=12, fontweight="bold")
    axes[1, 1].set_xlabel("Family Size (Self + Siblings/Spouse + Parents/Children)", fontsize=10)
    axes[1, 1].set_ylabel("Survival Rate", fontsize=10)
    axes[1, 1].set_ylim(0, 0.85)
    for p in axes[1, 1].patches:
        height = p.get_height()
        if height > 0:
            axes[1, 1].annotate(f"{height:.1%}", (p.get_x() + p.get_width() / 2., height + 0.02),
                                ha='center', va='bottom', fontsize=9, fontweight='bold')

    plt.suptitle("Zepto Analytics: 4-Chart Titanic Survival Data Story", fontsize=16, fontweight="bold", y=1.00)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()
    
    print(f"4-Chart Data Story saved to: {output_path}")
    return output_path


def run_full_eda(df: pd.DataFrame):
    """
    Executes all EDA steps in sequence.
    """
    missing_report, cleaned_df = analyze_missing_values(df)
    outliers = detect_outliers_iqr(cleaned_df)
    plot_correlation_heatmap(cleaned_df)
    plot_multivariate_data_story(cleaned_df)
    return missing_report, cleaned_df, outliers


if __name__ == "__main__":
    from ingest import load_local_titanic
    df = load_local_titanic()
    run_full_eda(df)
