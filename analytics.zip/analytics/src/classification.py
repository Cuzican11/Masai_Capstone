"""
Classification Modeling Module for Zepto Analytics (Module 2).
Builds a Scikit-Learn Pipeline with ColumnTransformer, Stratified Split,
and trains:
1. Logistic Regression
2. Decision Tree (with visual tree diagram export)
3. Random Forest Classifier
"""

import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, classification_report
)
from typing import Dict, Any, Tuple

FIGURES_DIR = os.path.join(os.path.dirname(__file__), "..", "reports", "figures")
os.makedirs(FIGURES_DIR, exist_ok=True)


def prepare_features_and_target(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series, list, list]:
    """
    Prepares raw features and target variable without leaking test data.
    Drops high-missing (>30%) and redundant columns.
    """
    data = df.copy()
    
    # Target
    y = data["survived"]
    
    # Feature Selection: Drop target, direct duplicates ('alive', 'survived'), and high-missing deck
    cols_to_drop = ["survived", "alive", "deck"]
    cols_to_drop = [c for c in cols_to_drop if c in data.columns]
    X = data.drop(columns=cols_to_drop)
    
    # Identify numeric and categorical columns
    numeric_features = ["pclass", "age", "sibsp", "parch", "fare"]
    categorical_features = ["sex", "embarked", "who", "adult_male", "alone"]
    
    # Keep only available features
    numeric_features = [f for f in numeric_features if f in X.columns]
    categorical_features = [f for f in categorical_features if f in X.columns]
    
    # Ensure categorical columns are object/str type for imputer and one-hot encoder
    for cat_col in categorical_features:
        X[cat_col] = X[cat_col].astype(str)
        
    X = X[numeric_features + categorical_features]
    return X, y, numeric_features, categorical_features


def build_preprocessor(numeric_features: list, categorical_features: list) -> ColumnTransformer:
    """
    Constructs a ColumnTransformer fitted ONLY on training data.
    - Numeric: Median Imputation + Standard Scaling
    - Categorical: Most Frequent Imputation + OneHotEncoding
    """
    numeric_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    
    categorical_transformer = Pipeline(steps=[
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore", drop="first", sparse_output=False))
    ])
    
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features)
        ]
    )
    return preprocessor


def evaluate_model(model: Any, X_test: pd.DataFrame, y_test: pd.Series, model_name: str) -> Dict[str, Any]:
    """
    Calculates comprehensive classification metrics on the holdout test set.
    """
    y_pred = model.predict(X_test)
    if hasattr(model, "predict_proba"):
        y_prob = model.predict_proba(X_test)[:, 1]
    else:
        y_prob = y_pred
        
    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred, zero_division=0)
    rec = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)
    auc = roc_auc_score(y_test, y_prob)
    
    print(f"\n--- Model Evaluation: {model_name} ---")
    print(f"Accuracy:  {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall:    {rec:.4f}")
    print(f"F1-Score:  {f1:.4f}")
    print(f"ROC-AUC:   {auc:.4f}")
    
    return {
        "Model": model_name,
        "Accuracy": round(acc, 4),
        "Precision": round(prec, 4),
        "Recall": round(rec, 4),
        "F1_Score": round(f1, 4),
        "ROC_AUC": round(auc, 4)
    }


def train_baseline_classification_models(df: pd.DataFrame):
    """
    5.1 Stratified Train/Test Split
    5.2 Scikit-Learn Pipelines
    5.3 Train Logistic Regression, Decision Tree (visualized), Random Forest
    """
    print("\n" + "=" * 60)
    print("5. CLASSIFICATION MODELING: PIPELINES & BASELINE TRAINING")
    print("=" * 60)
    
    X, y, num_cols, cat_cols = prepare_features_and_target(df)
    
    # 5.1 Stratified Train/Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    print(f"Stratified Split: Train={len(X_train)} rows ({y_train.mean():.2%} survived), Test={len(X_test)} rows ({y_test.mean():.2%} survived)")
    
    preprocessor = build_preprocessor(num_cols, cat_cols)
    
    results = []
    trained_pipelines = {}
    
    # -------------------------------------------------------------
    # 1. Logistic Regression
    # -------------------------------------------------------------
    log_reg_pipe = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", LogisticRegression(random_state=42, max_iter=1000))
    ])
    log_reg_pipe.fit(X_train, y_train)
    results.append(evaluate_model(log_reg_pipe, X_test, y_test, "Logistic Regression"))
    trained_pipelines["Logistic Regression"] = log_reg_pipe
    
    # -------------------------------------------------------------
    # 2. Decision Tree Classifier & Tree Visualization
    # -------------------------------------------------------------
    dt_pipe = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", DecisionTreeClassifier(max_depth=4, min_samples_leaf=5, random_state=42))
    ])
    dt_pipe.fit(X_train, y_train)
    results.append(evaluate_model(dt_pipe, X_test, y_test, "Decision Tree (max_depth=4)"))
    trained_pipelines["Decision Tree"] = dt_pipe
    
    # Visualize Decision Tree
    tree_model = dt_pipe.named_steps["classifier"]
    
    # Extract feature names after ColumnTransformer transformation
    fitted_preprocessor = dt_pipe.named_steps["preprocessor"]
    cat_encoder = fitted_preprocessor.named_transformers_["cat"].named_steps["onehot"]
    cat_feature_names = list(cat_encoder.get_feature_names_out(cat_cols))
    all_feature_names = num_cols + cat_feature_names
    
    plt.figure(figsize=(20, 10), dpi=300)
    plot_tree(
        tree_model,
        feature_names=all_feature_names,
        class_names=["Perished", "Survived"],
        filled=True,
        rounded=True,
        fontsize=9
    )
    plt.title("Decision Tree Classifier Visualization (Titanic Survival)", fontsize=14, fontweight="bold")
    dt_viz_path = os.path.join(FIGURES_DIR, "decision_tree.png")
    plt.savefig(dt_viz_path, dpi=300, bbox_inches="tight")
    plt.close()
    print(f"Decision Tree diagram saved to: {dt_viz_path}")
    
    # -------------------------------------------------------------
    # 3. Random Forest Classifier
    # -------------------------------------------------------------
    rf_pipe = Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(n_estimators=100, max_depth=6, random_state=42, oob_score=True))
    ])
    rf_pipe.fit(X_train, y_train)
    results.append(evaluate_model(rf_pipe, X_test, y_test, "Random Forest (Baseline)"))
    trained_pipelines["Random Forest Baseline"] = rf_pipe
    
    return results, trained_pipelines, (X_train, X_test, y_train, y_test, num_cols, cat_cols)


if __name__ == "__main__":
    from ingest import load_local_titanic
    df = load_local_titanic()
    results, pipelines, splits = train_baseline_classification_models(df)
    print("\nSummary Table:")
    print(pd.DataFrame(results))
