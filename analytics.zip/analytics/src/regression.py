"""
Regression Modeling and Heteroscedasticity Analysis Module for Zepto Analytics.
Objective:
1. Predict `fare` using multivariate linear regression with available features (pclass, age, sibsp, parch, sex, embarked).
2. Diagnostic evaluation of Heteroscedasticity (constant variance of residuals assumption):
   - Residuals vs. Fitted plot
   - Breusch-Pagan statistical hypothesis test
"""

import os
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from typing import Dict, Any, Tuple

FIGURES_DIR = os.path.join(os.path.dirname(__file__), "..", "reports", "figures")
os.makedirs(FIGURES_DIR, exist_ok=True)


def build_and_evaluate_fare_regression(df: pd.DataFrame) -> Tuple[Dict[str, Any], Any]:
    """
    7. Multivariate Linear Regression to predict `fare` and test for Heteroscedasticity.
    """
    print("\n" + "=" * 60)
    print("7. REGRESSION TASK: PREDICTING FARE & HETEROSCEDASTICITY CHECK")
    print("=" * 60)
    
    data = df.copy()
    
    # Feature setup
    target_col = "fare"
    num_features = ["pclass", "age", "sibsp", "parch"]
    cat_features = ["sex", "embarked"]
    
    # Drop rows missing target if any
    data = data.dropna(subset=[target_col])
    X = data[num_features + cat_features].copy()
    for cat_col in cat_features:
        X[cat_col] = X[cat_col].astype(str)
        
    y = data[target_col]
    
    # Train / Test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42
    )
    
    # Build Scikit-Learn Pipeline
    num_transformer = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler())
    ])
    cat_transformer = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(drop="first", sparse_output=False, handle_unknown="ignore"))
    ])
    preprocessor = ColumnTransformer([
        ("num", num_transformer, num_features),
        ("cat", cat_transformer, cat_features)
    ])
    
    reg_pipeline = Pipeline([
        ("preprocessor", preprocessor),
        ("regressor", LinearRegression())
    ])
    
    reg_pipeline.fit(X_train, y_train)
    y_pred_test = reg_pipeline.predict(X_test)
    
    r2 = r2_score(y_test, y_pred_test)
    mse = mean_squared_error(y_test, y_pred_test)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_test, y_pred_test)
    
    print("\nRegression Performance Metrics (Holdout Test Set):")
    print(f"  R-Squared (R²): {r2:.4f}")
    print(f"  RMSE:           ${rmse:.2f}")
    print(f"  MAE:            ${mae:.2f}")
    
    # -------------------------------------------------------------
    # Heteroscedasticity Diagnostic Analysis (Statsmodels OLS)
    # -------------------------------------------------------------
    # Transform training features for OLS
    X_train_trans = preprocessor.fit_transform(X_train)
    X_train_const = sm.add_constant(X_train_trans)
    
    ols_model = sm.OLS(y_train, X_train_const).fit()
    residuals = ols_model.resid
    fitted_vals = ols_model.fittedvalues
    
    # Breusch-Pagan Test
    # H0: Homoscedasticity (residuals are identically distributed with constant variance)
    # H1: Heteroscedasticity (variance of errors depends on input variables)
    bp_test = het_breuschpagan(residuals, X_train_const)
    bp_lm_stat = bp_test[0]
    bp_p_value = bp_test[1]
    bp_f_stat = bp_test[2]
    bp_f_p_value = bp_test[3]
    
    is_heteroscedastic = bp_p_value < 0.05
    
    print("\n" + "-" * 50)
    print("Heteroscedasticity Diagnostic Test (Breusch-Pagan):")
    print(f"  Lagrange Multiplier Stat: {bp_lm_stat:.4f}")
    print(f"  LM p-value:               {bp_p_value:.4e}")
    print(f"  F-Statistic:              {bp_f_stat:.4f}")
    print(f"  F-Test p-value:           {bp_f_p_value:.4e}")
    print(f"  Conclusion: {'Significant HETEROSCEDASTICITY detected (p < 0.05). Variance of errors is non-constant.' if is_heteroscedastic else 'Homoscedasticity assumption holds (p >= 0.05).'}")
    print("-" * 50)
    
    # Residual Plot (Fitted vs Residuals & Scale-Location)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5), dpi=300)
    
    # Plot 1: Residuals vs Fitted
    ax1.scatter(fitted_vals, residuals, alpha=0.6, edgecolors="k", color="#2980b9")
    ax1.axhline(0, color="red", linestyle="--", linewidth=1.5)
    ax1.set_xlabel("Fitted Values (Predicted Fare)", fontsize=11)
    ax1.set_ylabel("Residuals (Actual - Predicted)", fontsize=11)
    ax1.set_title("Residuals vs Fitted Values\n(Funnel shape indicates Heteroscedasticity)", fontsize=12, fontweight="bold")
    ax1.grid(True, linestyle=":", alpha=0.6)
    
    # Plot 2: Scale-Location Plot (sqrt(|standardized residuals|) vs fitted)
    std_resid = residuals / np.std(residuals)
    sqrt_abs_std_resid = np.sqrt(np.abs(std_resid))
    ax2.scatter(fitted_vals, sqrt_abs_std_resid, alpha=0.6, edgecolors="k", color="#8e44ad")
    ax2.set_xlabel("Fitted Values (Predicted Fare)", fontsize=11)
    ax2.set_ylabel("√|Standardized Residuals|", fontsize=11)
    ax2.set_title("Scale-Location Plot\n(Upward trend indicates error variance grows with Fare)", fontsize=12, fontweight="bold")
    ax2.grid(True, linestyle=":", alpha=0.6)
    
    plt.suptitle("Multivariate Linear Regression Heteroscedasticity Diagnostics", fontsize=14, fontweight="bold")
    plt.tight_layout()
    plot_path = os.path.join(FIGURES_DIR, "regression_heteroscedasticity.png")
    plt.savefig(plot_path, dpi=300)
    plt.close()
    print(f"Heteroscedasticity diagnostic plot saved to: {plot_path}")
    
    results = {
        "Task": "Multivariate Linear Regression (Target: Fare)",
        "R2_Score": round(r2, 4),
        "RMSE": round(rmse, 2),
        "MAE": round(mae, 2),
        "Breusch_Pagan_LM_Stat": round(bp_lm_stat, 4),
        "Breusch_Pagan_p_value": bp_p_value,
        "Heteroscedasticity_Present": is_heteroscedastic
    }
    
    return results, reg_pipeline


if __name__ == "__main__":
    from ingest import load_local_titanic
    df = load_local_titanic()
    build_and_evaluate_fare_regression(df)
