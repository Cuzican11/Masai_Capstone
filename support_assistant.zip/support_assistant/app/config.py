"""
Configuration settings for Zepto Support Assistant.
Handles environment variables and paths for ChromaDB, embeddings, and policies.
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# Mode: MOCK_LLM=1 for deterministic offline mode (default required), MOCK_LLM=0 for Gemini integration
MOCK_LLM = os.getenv("MOCK_LLM", "1").strip().lower() in ("1", "true", "yes")

# Gemini API Key (optional for MOCK_LLM=0)
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", os.getenv("GOOGLE_API_KEY", ""))

# Paths
POLICIES_DIR = os.getenv("POLICIES_DIR", str(BASE_DIR / "policies"))
CHROMA_PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", str(BASE_DIR / "chroma_db"))

# Embedding Model
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
COLLECTION_NAME = "zepto_policies"
