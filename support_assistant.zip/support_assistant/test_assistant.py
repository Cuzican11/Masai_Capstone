"""
Automated Test Suite for Zepto Support Assistant (Module 3).
Tests:
1. Retrieval and indexing from 8 policy files.
2. Intent Classification: policy_question vs general_question.
3. LangGraph Workflow in MOCK_LLM=1 mode.
4. FastAPI Endpoints (/health, /ask) via TestClient.
"""

import sys
import os
from pathlib import Path

# Add app directory to sys.path
app_dir = Path(__file__).resolve().parent / "app"
sys.path.insert(0, str(app_dir))

from fastapi.testclient import TestClient
from main import app
from schemas import AskResponse, IntentEnum
from graph import ask_assistant, CANNED_REFUSAL
from retrieval import index_policies, retrieve_top_k

client = TestClient(app)


def test_index_and_retrieval():
    print("\n[TEST 1] Testing Policy Indexing and Retrieval...")
    collection = index_policies(force_reindex=False)
    assert collection.count() > 0, "ChromaDB collection should have indexed chunks."
    
    # Test query
    results = retrieve_top_k("perishable milk refund window", k=3)
    assert len(results) == 3, f"Expected 3 chunks, got {len(results)}"
    assert any("policy_1.txt" in r["source"] or "policy_7.txt" in r["source"] for r in results)
    print(f"  -> Successfully retrieved {len(results)} chunks. Top source: {results[0]['source']}")


def test_graph_policy_question():
    print("\n[TEST 2] Testing Policy Question Routing & Answering...")
    query = "How long does a UPI refund take for cancelled orders?"
    response = ask_assistant(query)
    
    assert isinstance(response, AskResponse)
    assert response.confidence > 0.0
    assert len(response.sources) > 0
    assert "Zepto" in response.answer or "policy" in response.answer.lower()
    print(f"  -> Policy Answer Preview: {response.answer[:100]}...")
    print(f"  -> Sources: {response.sources}")


def test_graph_general_refusal():
    print("\n[TEST 3] Testing General Question Canned Refusal...")
    query = "Can you help me solve a calculus integration problem?"
    response = ask_assistant(query)
    
    assert isinstance(response, AskResponse)
    assert response.answer == CANNED_REFUSAL
    assert response.sources == []
    assert response.confidence == 1.0
    print("  -> Canned refusal correctly returned with 100% confidence and empty sources.")


def test_fastapi_endpoints():
    print("\n[TEST 4] Testing FastAPI Endpoints...")
    
    # 1. Health check
    health_res = client.get("/health")
    assert health_res.status_code == 200
    assert health_res.json()["status"] == "healthy"
    print("  -> GET /health: 200 OK")
    
    # 2. Ask policy question
    ask_payload = {"query": "What are the benefits of Zepto Pass membership?"}
    post_res = client.post("/ask", json=ask_payload)
    assert post_res.status_code == 200
    data = post_res.json()
    assert "answer" in data
    assert "sources" in data
    assert "confidence" in data
    assert data["confidence"] > 0
    print(f"  -> POST /ask: 200 OK. Confidence: {data['confidence']}")
    
    # 3. Ask general question
    general_payload = {"query": "Tell me a joke about robots."}
    gen_res = client.post("/ask", json=general_payload)
    assert gen_res.status_code == 200
    gen_data = gen_res.json()
    assert gen_data["answer"] == CANNED_REFUSAL
    assert gen_data["sources"] == []
    print("  -> POST /ask (general): 200 OK with canned refusal.")


def run_all_tests():
    print("=" * 60)
    print("RUNNING SUPPORT ASSISTANT TEST SUITE (Module 3)")
    print("=" * 60)
    test_index_and_retrieval()
    test_graph_policy_question()
    test_graph_general_refusal()
    test_fastapi_endpoints()
    print("\n" + "=" * 60)
    print("ALL SUPPORT ASSISTANT TESTS PASSED SUCCESSFULLY! (4/4)")
    print("=" * 60)


if __name__ == "__main__":
    run_all_tests()
