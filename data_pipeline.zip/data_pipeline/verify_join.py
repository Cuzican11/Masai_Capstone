"""
JOIN Verification Module for Zepto Data Pipeline.
Compares SQL-level JOIN (via pd.read_sql) vs Application-level JOIN (via pd.merge)
and strictly verifies that both approaches yield identical datasets.
"""

import os
import sqlite3
import pandas as pd
from pandas.testing import assert_frame_equal

DEFAULT_DB_PATH = os.path.join(os.path.dirname(__file__), "zepto.db")


def verify_join(db_path: str = DEFAULT_DB_PATH) -> bool:
    """
    Executes JOIN via pd.read_sql() and pd.merge(), and verifies equality.
    """
    print("=" * 60)
    print("Executing JOIN Verification (pd.read_sql vs pd.merge)...")
    print("=" * 60)
    
    if not os.path.exists(db_path):
        raise FileNotFoundError(f"Database file not found at: {db_path}. Run pipeline first.")
        
    conn = sqlite3.connect(db_path)
    
    # -------------------------------------------------------------
    # Method 1: SQL JOIN via pd.read_sql()
    # -------------------------------------------------------------
    sql_query = """
    SELECT 
        b.book_id,
        b.title,
        b.price_gbp,
        b.price_inr,
        b.star_rating,
        b.availability,
        b.category_id,
        c.category_name
    FROM books b
    JOIN categories c ON b.category_id = c.category_id
    ORDER BY b.book_id ASC;
    """
    df_sql_join = pd.read_sql_query(sql_query, conn)
    
    # -------------------------------------------------------------
    # Method 2: Pandas Merge via pd.merge()
    # -------------------------------------------------------------
    df_books = pd.read_sql_query("SELECT * FROM books ORDER BY book_id ASC;", conn)
    df_categories = pd.read_sql_query("SELECT * FROM categories ORDER BY category_id ASC;", conn)
    conn.close()
    
    df_pandas_merge = pd.merge(
        df_books,
        df_categories,
        on="category_id",
        how="inner"
    )
    
    # Ensure identical column order and sorting
    columns_order = [
        "book_id",
        "title",
        "price_gbp",
        "price_inr",
        "star_rating",
        "availability",
        "category_id",
        "category_name"
    ]
    df_pandas_merge = df_pandas_merge[columns_order].sort_values("book_id").reset_index(drop=True)
    df_sql_join = df_sql_join[columns_order].sort_values("book_id").reset_index(drop=True)
    
    # Ensure equivalent datatypes for boolean / numeric columns
    df_sql_join["availability"] = df_sql_join["availability"].astype(bool)
    df_pandas_merge["availability"] = df_pandas_merge["availability"].astype(bool)
    
    # -------------------------------------------------------------
    # Equality Verification
    # -------------------------------------------------------------
    print("\nSample records from pd.read_sql (SQL JOIN):")
    print(df_sql_join.head(3))
    
    print("\nSample records from pd.merge (Pandas JOIN):")
    print(df_pandas_merge.head(3))
    
    try:
        assert_frame_equal(df_sql_join, df_pandas_merge, check_dtype=True)
        print("\n" + "=" * 60)
        print("VERIFICATION SUCCESS: pd.read_sql() and pd.merge() results are 100% IDENTICAL!")
        print(f"Total verified records: {len(df_sql_join)}")
        print("=" * 60)
        return True
    except AssertionError as e:
        print("\nVERIFICATION FAILED: DataFrames differ!")
        print(e)
        return False


if __name__ == "__main__":
    verify_join()
