"""
FastAPI Deployment Module for Zepto Support Assistant (Module 3).
Exposes:
- POST /ask: Primary endpoint for querying policy assistant with strict Pydantic validation
- GET /health: Health check endpoint
- GET /: Service metadata and status
"""

import sys
import os
from pathlib import Path

# Add current directory to path
current_dir = Path(__file__).resolve().parent
if str(current_dir) not in sys.path:
    sys.path.insert(0, str(current_dir))

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from schemas import AskRequest, AskResponse
from graph import ask_assistant
from config import MOCK_LLM, GEMINI_API_KEY
from retrieval import index_policies

app = FastAPI(
    title="Zepto Customer Support AI Assistant",
    description="Intelligent RAG-powered Policy Assistant for Zepto quick-commerce using LangGraph, ChromaDB, and FastAPI.",
    version="1.0.0"
)

# Enable CORS for frontend clients
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """
    Ensures vector store is indexed with all 8 policies upon application startup.
    """
    print("FastAPI starting up: Checking / indexing ChromaDB policy collection...")
    try:
        index_policies(force_reindex=False)
        print("ChromaDB index ready.")
    except Exception as e:
        print(f"Warning during startup indexing: {e}")


@app.get("/", tags=["General"])
async def root():
    """
    Root endpoint displaying service info.
    """
    return {
        "service": "Zepto Customer Support AI Assistant",
        "status": "online",
        "mock_llm_mode": MOCK_LLM,
        "docs_url": "/docs",
        "endpoints": {
            "ask": "POST /ask",
            "health": "GET /health"
        }
    }


@app.get("/health", tags=["General"])
async def health_check():
    """
    Health check endpoint verifying system readiness.
    """
    return {
        "status": "healthy",
        "mock_mode": MOCK_LLM,
        "gemini_configured": bool(GEMINI_API_KEY)
    }


@app.post("/ask", response_model=AskResponse, status_code=status.HTTP_200_OK, tags=["RAG Assistant"])
async def ask_question(request: AskRequest) -> AskResponse:
    """
    Processes customer queries through the LangGraph StateGraph.
    - Classifies intent (policy_question vs general_question)
    - Returns canned refusal for general inquiries
    - Retrieves top 3 ChromaDB chunks and generates structured response for policy questions
    """
    if not request.query or not request.query.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Query string cannot be empty."
        )
        
    try:
        response = ask_assistant(request.query.strip())
        return response
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"An error occurred while processing query: {str(e)}"
        )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
