"""
Optimization and Advanced Modeling Module for Zepto Analytics (Module 2).
Covers:
6.1 Class Imbalance Comparison:
    - 1. Baseline
    - 2. Class Weights
    - 3. SMOTE
6.2 Random Forest Hyperparameter Tuning with GridSearchCV and OOB Scoring.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV, StratifiedKFold
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline as ImbPipeline
from typing import Dict, Any, List, Tuple
from classification import build_preprocessor, evaluate_model


def compare_class_imbalance_approaches(
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: pd.Series,
    y_test: pd.Series,
    num_cols: list,
    cat_cols: list
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """
    6.1 Compares three techniques for handling class imbalance:
    1. Baseline (Standard Random Forest)
    2. Class Weights (class_weight='balanced')
    3. SMOTE (Synthetic Minority Over-sampling Technique via ImbPipeline)
    """
    print("\n" + "=" * 60)
    print("6.1 CLASS IMBALANCE COMPARISON (BASELINE vs CLASS WEIGHTS vs SMOTE)")
    print("=" * 60)
    
    preprocessor = build_preprocessor(num_cols, cat_cols)
    results = []
    imbalance_pipelines = {}
    
    # -------------------------------------------------------------
    # Approach 1: Baseline (No Balancing)
    # -------------------------------------------------------------
    pipe_baseline = ImbPipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(n_estimators=150, max_depth=6, random_state=42, oob_score=True))
    ])
    pipe_baseline.fit(X_train, y_train)
    res_baseline = evaluate_model(pipe_baseline, X_test, y_test, "Random Forest (Baseline)")
    results.append(res_baseline)
    imbalance_pipelines["Baseline"] = pipe_baseline
    
    # -------------------------------------------------------------
    # Approach 2: Class Weights (class_weight='balanced')
    # -------------------------------------------------------------
    pipe_weights = ImbPipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(
            n_estimators=150, max_depth=6, class_weight="balanced", random_state=42, oob_score=True
        ))
    ])
    pipe_weights.fit(X_train, y_train)
    res_weights = evaluate_model(pipe_weights, X_test, y_test, "Random Forest (Class Weights)")
    results.append(res_weights)
    imbalance_pipelines["Class_Weights"] = pipe_weights
    
    # -------------------------------------------------------------
    # Approach 3: SMOTE (Oversampling minority class on training data only)
    # -------------------------------------------------------------
    pipe_smote = ImbPipeline(steps=[
        ("preprocessor", preprocessor),
        ("smote", SMOTE(random_state=42)),
        ("classifier", RandomForestClassifier(n_estimators=150, max_depth=6, random_state=42))
    ])
    pipe_smote.fit(X_train, y_train)
    res_smote = evaluate_model(pipe_smote, X_test, y_test, "Random Forest (SMOTE)")
    results.append(res_smote)
    imbalance_pipelines["SMOTE"] = pipe_smote
    
    comparison_df = pd.DataFrame(results)
    print("\n" + "-" * 60)
    print("CLASS IMBALANCE RESULTS COMPARISON TABLE:")
    print("-" * 60)
    print(comparison_df.to_string(index=False))
    
    return results, imbalance_pipelines


def tune_random_forest_with_gridsearch(
    X_train: pd.DataFrame,
    X_test: pd.DataFrame,
    y_train: pd.Series,
    y_test: pd.Series,
    num_cols: list,
    cat_cols: list
) -> Tuple[Dict[str, Any], Any]:
    """
    6.2 Performs Hyperparameter Tuning on Random Forest using GridSearchCV
    and evaluates Out-of-Bag (OOB) scoring.
    """
    print("\n" + "=" * 60)
    print("6.2 RANDOM FOREST HYPERPARAMETER TUNING (GridSearchCV + OOB Score)")
    print("=" * 60)
    
    preprocessor = build_preprocessor(num_cols, cat_cols)
    
    pipe = ImbPipeline(steps=[
        ("preprocessor", preprocessor),
        ("classifier", RandomForestClassifier(random_state=42, oob_score=True))
    ])
    
    param_grid = {
        "classifier__n_estimators": [100, 200, 300],
        "classifier__max_depth": [4, 6, 8, None],
        "classifier__min_samples_split": [2, 5, 10],
        "classifier__min_samples_leaf": [1, 2, 4],
        "classifier__criterion": ["gini", "entropy"]
    }
    
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    grid_search = GridSearchCV(
        estimator=pipe,
        param_grid=param_grid,
        cv=cv,
        scoring="f1",
        n_jobs=-1,
        verbose=1
    )
    
    print("Starting Grid Search CV across 5 folds...")
    grid_search.fit(X_train, y_train)
    
    best_params = grid_search.best_params_
    best_cv_score = grid_search.best_score_
    best_model = grid_search.best_estimator_
    
    # Calculate OOB score from the best estimator's classifier
    rf_classifier = best_model.named_steps["classifier"]
    oob_score = rf_classifier.oob_score_
    
    print("\n" + "-" * 50)
    print("GridSearchCV Results:")
    print(f"Best CV F1-Score: {best_cv_score:.4f}")
    print(f"Out-of-Bag (OOB) Score: {oob_score:.4f}")
    print("Best Hyperparameters:")
    for k, v in best_params.items():
        print(f"  {k}: {v}")
    print("-" * 50)
    
    # Evaluate on Holdout Test Set
    test_eval = evaluate_model(best_model, X_test, y_test, "Tuned Random Forest (GridSearchCV)")
    test_eval["OOB_Score"] = round(oob_score, 4)
    test_eval["Best_CV_F1"] = round(best_cv_score, 4)
    
    return test_eval, best_model


if __name__ == "__main__":
    from ingest import load_local_titanic
    from classification import prepare_features_and_target
    from sklearn.model_selection import train_test_split
    
    df = load_local_titanic()
    X, y, num_cols, cat_cols = prepare_features_and_target(df)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    
    imb_results, _ = compare_class_imbalance_approaches(X_train, X_test, y_train, y_test, num_cols, cat_cols)
    tuned_res, _ = tune_random_forest_with_gridsearch(X_train, X_test, y_train, y_test, num_cols, cat_cols)
