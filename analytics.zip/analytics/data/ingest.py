"""
Data Ingestion Module for Zepto Analytics Pipeline.
Loads the Titanic dataset exactly once using sns.load_dataset('titanic')
and saves it locally to analytics/data/titanic.csv.
All downstream analytics strictly read from the local CSV file.
"""

import os
import seaborn as sns
import pandas as pd

DATA_DIR = os.path.dirname(__file__)
LOCAL_CSV_PATH = os.path.join(DATA_DIR, "titanic.csv")


def ingest_titanic_data(output_path: str = LOCAL_CSV_PATH) -> pd.DataFrame:
    """
    Fetches the Titanic dataset from Seaborn and caches it locally as a CSV.
    """
    print("=" * 60)
    print("Ingesting Titanic dataset from Seaborn...")
    print("=" * 60)
    
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Ingest from Seaborn exactly once
    df = sns.load_dataset("titanic")
    
    # Save locally
    df.to_csv(output_path, index=False)
    print(f"Dataset saved locally to: {output_path}")
    print(f"Dataset shape: {df.shape} (Rows: {df.shape[0]}, Columns: {df.shape[1]})")
    print(f"Columns: {list(df.columns)}")
    return df


def load_local_titanic(csv_path: str = LOCAL_CSV_PATH) -> pd.DataFrame:
    """
    Loads the cached Titanic dataset from the local CSV file.
    """
    if not os.path.exists(csv_path):
        print("Local CSV not found. Ingesting first...")
        return ingest_titanic_data(csv_path)
        
    df = pd.read_csv(csv_path)
    return df


if __name__ == "__main__":
    ingest_titanic_data()
