"""
Retrieval Module for Zepto Support Assistant (Module 3).
Loads 8 policy text files, splits into logical chunks, embeds via sentence-transformers (all-MiniLM-L6-v2),
stores in local ChromaDB, and retrieves top 3 relevant chunks.
"""

import os
import glob
from pathlib import Path
from typing import List, Dict, Any
import chromadb
from chromadb.utils import embedding_functions
from sentence_transformers import SentenceTransformer
from config import POLICIES_DIR, CHROMA_PERSIST_DIR, EMBEDDING_MODEL_NAME, COLLECTION_NAME


class SentenceTransformerEmbeddingFunction(chromadb.EmbeddingFunction):
    """
    Custom ChromaDB Embedding Function wrapping sentence-transformers.
    """
    def __init__(self, model_name: str = EMBEDDING_MODEL_NAME):
        self.model = SentenceTransformer(model_name)

    def __call__(self, input: chromadb.Documents) -> chromadb.Embeddings:
        embeddings = self.model.encode(input, convert_to_numpy=True)
        return embeddings.tolist()


def get_chroma_client():
    """
    Returns persistent ChromaDB client.
    """
    os.makedirs(CHROMA_PERSIST_DIR, exist_ok=True)
    return chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)


def chunk_policy_text(file_path: str) -> List[Dict[str, Any]]:
    """
    Chunks a policy file by its major numbered sections while preserving header metadata.
    """
    filename = os.path.basename(file_path)
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
        
    lines = content.strip().split("\n")
    header = lines[0] if lines else filename
    
    # Split on numbered sections or double newlines
    raw_sections = content.split("\n\n")
    chunks = []
    
    current_section = ""
    for sec in raw_sections:
        sec = sec.strip()
        if not sec:
            continue
        if len(sec) < 50 and not current_section:
            current_section = sec + "\n"
            continue
        
        chunk_text = (current_section + "\n" + sec).strip() if current_section else sec
        current_section = ""
        
        chunks.append({
            "source": filename,
            "policy_title": header,
            "text": chunk_text
        })
        
    return chunks


def index_policies(policies_dir: str = POLICIES_DIR, force_reindex: bool = False):
    """
    Indexes all 8 policy files from policies_dir into local ChromaDB.
    """
    client = get_chroma_client()
    embedding_fn = SentenceTransformerEmbeddingFunction(EMBEDDING_MODEL_NAME)
    
    existing_collections = [c.name for c in client.list_collections()]
    
    if force_reindex and COLLECTION_NAME in existing_collections:
        client.delete_collection(COLLECTION_NAME)
        existing_collections.remove(COLLECTION_NAME)
        
    if COLLECTION_NAME in existing_collections:
        collection = client.get_collection(name=COLLECTION_NAME, embedding_function=embedding_fn)
        if collection.count() > 0:
            print(f"ChromaDB collection '{COLLECTION_NAME}' already contains {collection.count()} chunks.")
            return collection
            
    collection = client.create_collection(
        name=COLLECTION_NAME,
        embedding_function=embedding_fn,
        metadata={"description": "Zepto Customer Service Policies Knowledge Base"}
    )
    
    policy_files = sorted(glob.glob(os.path.join(policies_dir, "policy_*.txt")))
    if not policy_files:
        raise FileNotFoundError(f"No policy files found in: {policies_dir}")
        
    print(f"Indexing {len(policy_files)} policy files into ChromaDB...")
    
    all_docs = []
    all_metadatas = []
    all_ids = []
    
    chunk_counter = 0
    for p_file in policy_files:
        chunks = chunk_policy_text(p_file)
        for chunk in chunks:
            chunk_id = f"chunk_{chunk_counter}_{chunk['source']}"
            all_docs.append(chunk["text"])
            all_metadatas.append({
                "source": chunk["source"],
                "policy_title": chunk["policy_title"]
            })
            all_ids.append(chunk_id)
            chunk_counter += 1
            
    collection.add(
        documents=all_docs,
        metadatas=all_metadatas,
        ids=all_ids
    )
    
    print(f"Successfully indexed {len(all_docs)} chunks into ChromaDB '{COLLECTION_NAME}'!")
    return collection


def retrieve_top_k(query: str, k: int = 3) -> List[Dict[str, Any]]:
    """
    Retrieves the top k relevant policy chunks from ChromaDB for a given query.
    """
    client = get_chroma_client()
    embedding_fn = SentenceTransformerEmbeddingFunction(EMBEDDING_MODEL_NAME)
    collection = client.get_or_create_collection(name=COLLECTION_NAME, embedding_function=embedding_fn)
    
    if collection.count() == 0:
        # Index on demand
        index_policies(force_reindex=True)
        collection = client.get_collection(name=COLLECTION_NAME, embedding_function=embedding_fn)
        
    results = collection.query(
        query_texts=[query],
        n_results=min(k, collection.count()),
        include=["documents", "metadatas", "distances"]
    )
    
    retrieved = []
    if results and "documents" in results and results["documents"]:
        docs = results["documents"][0]
        metas = results["metadatas"][0] if "metadatas" in results else [{}] * len(docs)
        dists = results["distances"][0] if "distances" in results else [0.0] * len(docs)
        
        for doc, meta, dist in zip(docs, metas, dists):
            # Calculate similarity score from distance
            sim_score = max(0.0, min(1.0, 1.0 - (dist / 2.0)))
            retrieved.append({
                "source": meta.get("source", "unknown"),
                "policy_title": meta.get("policy_title", "Zepto Policy"),
                "text": doc,
                "score": round(sim_score, 4)
            })
            
    return retrieved


if __name__ == "__main__":
    coll = index_policies(force_reindex=True)
    sample_query = "What is the refund time for UPI payments and perishable items?"
    hits = retrieve_top_k(sample_query, k=3)
    print(f"\nQuery: '{sample_query}'")
    for i, hit in enumerate(hits):
        print(f"\n--- Hit {i+1} (Source: {hit['source']}, Score: {hit['score']}) ---")
        print(hit["text"][:200] + "...")
