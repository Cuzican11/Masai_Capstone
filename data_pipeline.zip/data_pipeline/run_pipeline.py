"""
Master Runner for Zepto Data Pipeline (Module 1).
Executes ETL: Extract -> Transform -> Load -> 5 SQL Queries -> JOIN Verification.
"""

import os
import sqlite3
import pandas as pd
from scraper import scrape_all_books
from transform import transform_data, prepare_normalized_tables
from database import init_database, load_data, DEFAULT_DB_PATH
from verify_join import verify_join


def run_sql_queries(db_path: str = DEFAULT_DB_PATH):
    """
    Executes and formats all 5 queries from queries.sql against the database.
    """
    print("\n" + "=" * 60)
    print("Executing 5 Analytical SQL Queries against zepto.db...")
    print("=" * 60)
    
    queries_file = os.path.join(os.path.dirname(__file__), "queries.sql")
    with open(queries_file, "r", encoding="utf-8") as f:
        sql_content = f.read()
        
    # Split queries by semicolon
    statements = [stmt.strip() for stmt in sql_content.split(";") if stmt.strip()]
    
    conn = sqlite3.connect(db_path)
    
    query_descriptions = [
        "Query 1: Top 5 Most Expensive In-Stock Books (WHERE, ORDER BY, LIMIT, JOIN)",
        "Query 2: Distinct Star Ratings & Pricing Distribution (DISTINCT, ORDER BY)",
        "Query 3: Books in Curated Categories with Rating >= 3 (IN, JOIN, ORDER BY)",
        "Query 4: Mid-tier High-Rated Books between 2000 & 4500 INR (BETWEEN, WHERE, ORDER BY)",
        "Query 5: Category Inventory & Pricing Aggregation (JOIN, GROUP BY, ORDER BY)"
    ]
    
    for i, stmt in enumerate(statements):
        desc = query_descriptions[i] if i < len(query_descriptions) else f"Query {i+1}"
        print(f"\n--- {desc} ---")
        df_result = pd.read_sql_query(stmt, conn)
        print(df_result.to_string(index=False))
        
    conn.close()


def main():
    print("************************************************************")
    print("       ZEPTO DATA PIPELINE (MODULE 1) - STARTING ETL        ")
    print("************************************************************\n")
    
    # Step 1: Extract
    raw_books = scrape_all_books(min_total_books=60)
    
    # Step 2: Transform
    print("\n" + "=" * 60)
    print("Step 2: Cleaning and transforming extracted records...")
    print("=" * 60)
    transformed_df = transform_data(raw_books)
    categories_df, books_df = prepare_normalized_tables(transformed_df)
    print(f"Transformed {len(books_df)} books across {len(categories_df)} categories.")
    
    # Step 3: Load
    print("\n" + "=" * 60)
    print("Step 3: Loading normalized tables into SQLite (zepto.db)...")
    print("=" * 60)
    init_database(DEFAULT_DB_PATH)
    load_data(categories_df, books_df, DEFAULT_DB_PATH)
    
    # Step 4: Run 5 Analytical Queries
    run_sql_queries(DEFAULT_DB_PATH)
    
    # Step 5: Verification
    verify_join(DEFAULT_DB_PATH)
    
    print("\n************************************************************")
    print("       MODULE 1 DATA PIPELINE COMPLETED SUCCESSFULLY!       ")
    print("************************************************************")


if __name__ == "__main__":
    main()
