"""
Database Loading Module for Zepto Data Pipeline.
Creates and populates normalized SQLite database (zepto.db) with Foreign Key constraints.
"""

import sqlite3
import os
import pandas as pd
from typing import Tuple

DEFAULT_DB_PATH = os.path.join(os.path.dirname(__file__), "zepto.db")


def get_db_connection(db_path: str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    """
    Returns an SQLite connection with Foreign Keys enabled.
    """
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_database(db_path: str = DEFAULT_DB_PATH):
    """
    Initializes the relational SQLite database schema with categories and books tables.
    """
    conn = get_db_connection(db_path)
    cursor = conn.cursor()
    
    # Drop existing tables if re-initializing
    cursor.execute("DROP TABLE IF EXISTS books;")
    cursor.execute("DROP TABLE IF EXISTS categories;")
    
    # Create categories table
    cursor.execute("""
    CREATE TABLE categories (
        category_id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_name TEXT UNIQUE NOT NULL
    );
    """)
    
    # Create books table with foreign key constraint
    cursor.execute("""
    CREATE TABLE books (
        book_id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        price_gbp REAL NOT NULL,
        price_inr REAL NOT NULL,
        star_rating INTEGER NOT NULL,
        availability BOOLEAN NOT NULL,
        category_id INTEGER NOT NULL,
        FOREIGN KEY (category_id) REFERENCES categories (category_id) ON DELETE CASCADE
    );
    """)
    
    conn.commit()
    conn.close()
    print(f"Database schema successfully initialized at: {db_path}")


def load_data(categories_df: pd.DataFrame, books_df: pd.DataFrame, db_path: str = DEFAULT_DB_PATH):
    """
    Loads categories and books dataframes into the SQLite database.
    """
    conn = get_db_connection(db_path)
    
    # Insert categories
    categories_df.to_sql("categories", conn, if_exists="append", index=False)
    
    # Insert books
    books_df.to_sql("books", conn, if_exists="append", index=False)
    
    conn.commit()
    
    # Verify counts
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM categories;")
    cat_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM books;")
    book_count = cursor.fetchone()[0]
    
    conn.close()
    
    print(f"Loaded {cat_count} categories and {book_count} books into SQLite database.")
    return cat_count, book_count


if __name__ == "__main__":
    init_database()
