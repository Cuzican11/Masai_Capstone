"""
Transformation Module for Zepto Data Pipeline.
Cleans raw scraped book data:
1. Maps star ratings from words ("One".."Five") to integers (1..5).
2. Converts availability text to boolean (True/False).
3. Converts GBP price to INR with fixed exchange rate (1 GBP = 105.50 INR).
"""

import pandas as pd
from typing import List, Dict, Any, Tuple

# Rating mapping dictionary
RATING_MAP = {
    "One": 1,
    "Two": 2,
    "Three": 3,
    "Four": 4,
    "Five": 5,
    "Zero": 0
}

# Fixed currency exchange rate
GBP_TO_INR_RATE = 105.50


def transform_data(raw_records: List[Dict[str, Any]]) -> pd.DataFrame:
    """
    Transforms raw book records into a clean, normalized pandas DataFrame.
    """
    df = pd.DataFrame(raw_records)
    
    # 1. Star Rating Conversion
    df["star_rating"] = df["star_rating"].map(lambda r: RATING_MAP.get(r, 0)).astype(int)
    
    # 2. Availability Conversion
    df["availability"] = df["availability"].apply(
        lambda x: True if "in stock" in str(x).lower() or "available" in str(x).lower() else False
    )
    
    # 3. Currency Conversion: GBP to INR
    df["price_gbp"] = df["price"].astype(float)
    df["price_inr"] = (df["price_gbp"] * GBP_TO_INR_RATE).round(2)
    
    # Drop original price column in favor of explicit price_gbp
    df = df.drop(columns=["price"])
    
    # Clean text columns
    df["title"] = df["title"].astype(str).str.strip()
    df["category"] = df["category"].astype(str).str.strip()
    
    return df


def prepare_normalized_tables(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Splits the transformed dataframe into normalized relational tables:
    1. categories (category_id, category_name)
    2. books (title, price_gbp, price_inr, star_rating, availability, category_id)
    """
    # Create unique categories table
    unique_categories = sorted(df["category"].unique())
    categories_df = pd.DataFrame({
        "category_id": range(1, len(unique_categories) + 1),
        "category_name": unique_categories
    })
    
    # Map category_name to category_id in books
    category_map = dict(zip(categories_df["category_name"], categories_df["category_id"]))
    
    books_df = df.copy()
    books_df["category_id"] = books_df["category"].map(category_map)
    books_df = books_df.drop(columns=["category"])
    
    # Reorder columns
    books_df = books_df[["title", "price_gbp", "price_inr", "star_rating", "availability", "category_id"]]
    
    return categories_df, books_df


if __name__ == "__main__":
    sample_raw = [
        {"title": "Sample Book 1", "price": 25.00, "star_rating": "Three", "availability": "In stock (22 available)", "category": "Mystery"},
        {"title": "Sample Book 2", "price": 10.50, "star_rating": "Five", "availability": "In stock", "category": "Travel"}
    ]
    transformed = transform_data(sample_raw)
    cats, books = prepare_normalized_tables(transformed)
    print("Categories Table:\n", cats)
    print("\nBooks Table:\n", books)
